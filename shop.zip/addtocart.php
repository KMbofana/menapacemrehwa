<?php

echo $_SESSION["qty"];
echo $_SESSION["qty"];
echo $_SESSION["qty"];
// if (isset($_POST["add"]) )
//    {
//    $i = $_GET["add"];
//    $qty = $_SESSION["qty"][$i] + 1;
//    $_SESSION["amounts"][$i] = $amounts[$i] * $qty;
//    $_SESSION["cart"][$i] = $i;
//    $_SESSION["qty"][$i] = $qty;
//    echo "<script type='text/javascript'>
//    alert('Item Added to Cart. Scroll down to see Cart Items')
//    </script>";
   
//  }


?>