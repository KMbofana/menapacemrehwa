

<div style="margin-left:300px;">
<form class="form-horizontal" action="stock.php" method="POST" enctype="multipart/form-data">
                  <div class="form-group">
                    <label class="col-sm-2 control-label">Product Name</label>
                    <div class="col-sm-4">
                      <input type="text" class="form-control" name="product_name">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-2 control-label">Price</label>
                    <div class="col-sm-4">
                      <input type="text" class="form-control" placeholder="type assignment" name="price"><br/>                   
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-2 control-label">Quantity</label>
                    <div class="col-sm-4">
                      <input type="text" class="form-control" placeholder="type assignment" name="quantity"><br/>                   
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-2 control-label">Product Image</label>
                    <div class="col-sm-4">
                    <input type="file" class="form-control-file" name="image">
                    </div>
                  </div>
                 
                  <div class="col-sm-4 panel-body" style="margin-left:120px;">
                    <button type="submit" class="btn btn-primary btn-lg btn-block">Add To Stocks</button>
                  </div>
                </form>
                </div>
