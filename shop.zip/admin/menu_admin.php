<?php

?>

<div class="container">
	<div class="row">
		<div class="col-md-2">
			<div class="list-group">
				<a href="#" class="list-group-item">Products</a>
				<a href="#" class="list-group-item">Orders</a>
				<a href="#" class="list-group-item">Users</a>
				<a href="#" class="list-group-item">Settings</a>
				<a href="destroy.php" class="list-group-item">Logout</a>
			</div>
		</div>
		<div class="col-md-9"></div>
	</div>
</div>