<?php 

$con=mysqli_connect("localhost","root","","max_shop")or die("Connection failed: " . mysqli_connect_error());

?>