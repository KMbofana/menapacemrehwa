<?php 

include("./database/dbcon.php");
session_start();

if(isset($_SESSION['email'])){

// $_SESSION['buyer_id']; assigned when buyer pays for the goods or choose to pay on delivery
$email=$_SESSION['email'];

$query=mysqli_query($con,"SELECT `status` FROM `paid_for_items` WHERE `email`='$email'");
$check=mysqli_num_rows($query);
$result=mysqli_fetch_assoc($query);


if($check > 0){
    $status=$result['status'];
    
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">


</head>
<body class="container"> 
<h2 style="text-align:center">Delivery Progress for <?php echo "Client : ".$_SESSION['email'];?></h2></br>


    <?php 
    if(isset($status) && $status=="pending"){
    ?>
    <div class="progress">
        <div class="progress-bar" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"><?php echo $status; ?></div>
    </div>
 <?php }
 
    elseif(isset($status) && $status=="items in transit")
    {?>
    <div class="progress">
        <div class="progress-bar" role="progressbar" style="width: 15%" aria-valuenow="15" aria-valuemin="0" aria-valuemax="100">Order Received</div>
        <div class="progress-bar bg-success" role="progressbar" style="width: 35%" aria-valuenow="35" aria-valuemin="0" aria-valuemax="100"><?php echo $status ?></div>
    </div>
<?php } elseif(isset($status)&& $status=="items delivered"){
     ?>
     <div class="progress">
        <div class="progress-bar" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">Order Received</div>
        <div class="progress-bar bg-success" role="progressbar" style="width: 35%" aria-valuenow="35" aria-valuemin="0" aria-valuemax="100">Items in transit</div>
        <div class="progress-bar bg-info" role="progressbar" style="width: 40%" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"><?php echo $status ?></div>
      </div></br>
      <h6 style="text-align:center">Contact Maxtraenergy Solution @:</h6>
      <p style="text-align:center">WhatsApp: 0779 363 209</p>
      <p style="text-align:center">Facebook: Maxutrae Energy</p>
      <p style="text-align:center">Twitter: Maxutrae Energy</p>
      <p style="text-align:center">Instagram: Maxutrae Energy</p>
      <p style="text-align:center">Email: sales@maxutraenergy.co.zw </p>
      <div style="display:flex; justify-content:center; margin-top:50px;">
      
      <form method="post" action="acknowledge.php">
          <input type="text" name="ack" id="" value="<?php echo $_SESSION['email']; ?>" hidden>
        <input type="submit" value="Acknowledge Reception">
      </form>
     
      </div>
      
  <?php   }
  else{
      ?>
<h4>No Items send for delivery, Order Items</h4>
  <?php
  }
  ?>
</div>

<?php include('./admin/footer.php')?>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>

</html>

<?php } 
}
// else{
//    echo "<script type='text/javascript'> 
//    alert('Session Expired Please Login to track your order')
               
//     window.location='login_client.php'
//     </script>";
// }
?>